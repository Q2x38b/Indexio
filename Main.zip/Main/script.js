const newsAPIKey = 'YOUR_NEWSAPI_KEY';
const stackExchangeAPIUrl = 'https://api.stackexchange.com/2.3/search?order=desc&sort=activity&site=stackoverflow';
const resultsCounter = document.getElementById('resultsCount');

function displayResults(source, results) {
    const dropdownContent = document.getElementById('dropdownContent');
    dropdownContent.innerHTML = '';
    
    results.forEach(item => {
        const resultElement = document.createElement('div');
        const title = item.title || item.name || item.headline;
        const url = item.link || `https://en.wikipedia.org/?curid=${item.pageid}`;
        const snippet = item.snippet || item.excerpt || item.content || '';

        resultElement.className = 'result-item';
        resultElement.innerHTML = `
            <div class="result-title"><a href="${url}" target="_blank">${title}</a></div>
            <div class="result-url">${url}</div>
            <div class="result-snippet">${snippet}</div>
            <div class="result-source">${source}</div>
        `;
        dropdownContent.appendChild(resultElement);
    });
    resultsCounter.textContent = `Results Count : ${results.length}`;
}

function executeSearch() {
    const searchTerm = document.getElementById('query').value;
    const searchEngine = document.getElementById('engine').value;

    if (searchEngine === 'wikipedia') {
        searchWikipedia(searchTerm);
    } else if (searchEngine === 'stackOverflow') {
        searchStackOverflow(searchTerm);
    } else if (searchEngine === 'news') {
        searchNews(searchTerm);
    } else {
        window.open(searchEngine + encodeURIComponent(searchTerm), '_blank');
    }
}

function searchWikipedia(searchTerm) {
    const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&origin=*&srlimit=5&srsearch=${encodeURIComponent(searchTerm)}`;
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.query.search.length > 0) {
                displayResults('Wikipedia', data.query.search);
            } else {
                document.getElementById('dropdownContent').innerHTML = '<div class="result-item">No results found on Wikipedia.</div>';
            }
        })
        .catch(error => console.error('Error fetching Wikipedia data:', error));
}

function searchNews(searchTerm) {
    const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(searchTerm)}&apiKey=${newsAPIKey}`;
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.articles.length > 0) {
                displayResults('News', data.articles);
            } else {
                document.getElementById('dropdownContent').innerHTML = '<div class="result-item">No results found in News.</div>';
            }
        })
        .catch(error => console.error('Error fetching news data:', error));
}

function searchStackOverflow(searchTerm) {
    const url = `${stackExchangeAPIUrl}&intitle=${encodeURIComponent(searchTerm)}`;
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.items.length > 0) {
                displayResults('Stack Overflow', data.items);
            } else {
                document.getElementById('dropdownContent').innerHTML = '<div class="result-item">No results found on Stack Overflow.</div>';
            }
        })
        .catch(error => console.error('Error fetching Stack Overflow data:', error));
}

async function getDefinition() {
    const word = document.getElementById("query").value;
    const url = `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`;

    const response = await fetch(url);
    if (response.ok) {
        const data = await response.json();
        const definition = data[0].meanings[0].definitions[0].definition;
        document.getElementById("definition").innerText = `Definition: ${definition}`;
    } else {
        document.getElementById("definition").innerText = "Definition not found.";
    }
}

function clearInput() {
 location.reload();
}